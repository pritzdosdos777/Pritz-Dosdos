31.5-second gospel edit in Remotion, 1920x1080 at 30fps.
Soft American female AI voice (Kokoro af_heart), full supplied script, original piano-and-pad score, brighter cropped footage, timed text and warm closing grade. No B-roll.
Run npm ci then npm run dev. Composition: HelpIsHere.
Export: npx remotion render HelpIsHere help-is-here.mp4
The supplied clip starts after the HELP-to-HELL transformation. The narration describes it while the footage shows HELL already formed.
