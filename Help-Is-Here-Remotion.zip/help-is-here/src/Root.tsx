import React from 'react';
import {AbsoluteFill,Composition,Sequence,CanvasImage,staticFile,useCurrentFrame,useVideoConfig,interpolate} from 'remotion';
import {Video,Audio} from '@remotion/media';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const Words=({children,large=false,accent=false}:{children:React.ReactNode;large?:boolean;accent?:boolean})=>{const f=useCurrentFrame();return <AbsoluteFill style={{justifyContent:'flex-end',alignItems:'center',paddingBottom:large?136:98,opacity:interpolate(f,[0,10],[0,1],clamp),translate:`0px ${interpolate(f,[0,15],[12,0],clamp)}px`}}><div style={{maxWidth:1480,textAlign:'center',fontFamily:large?'Georgia, serif':'Arial, sans-serif',fontSize:large?78:48,fontWeight:large?400:600,lineHeight:1.25,color:accent?'#f1d49b':'#fff7e9',textShadow:'0 3px 20px #000',letterSpacing:large?3:.2}}>{children}</div></AbsoluteFill>};
const Gospel=()=>{const {fps}=useVideoConfig();const f=useCurrentFrame();return <AbsoluteFill style={{background:'#090d10'}}>
<Sequence name="Alex introduction" durationInFrames={6*fps} premountFor={fps}><Video src={staticFile('scene.mp4')} trimBefore={5*fps} durationInFrames={1.2*fps} playbackRate={.2} muted premountFor={fps} style={{width:'100%',height:'100%',objectFit:'cover'}}/></Sequence>
<Sequence name="HELL reveal" from={6*fps} durationInFrames={7.5*fps} premountFor={fps}><Video src={staticFile('scene.mp4')} trimBefore={6.5*fps} durationInFrames={6*fps} playbackRate={.8} muted premountFor={fps} style={{width:'100%',height:'100%',objectFit:'cover'}}/></Sequence>
<Sequence name="Rescue reflection" from={13.5*fps} durationInFrames={6.5*fps} premountFor={fps}><CanvasImage src={staticFile('alex.jpg')} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'cover',scale:interpolate(f,[13.5*fps,20.0*fps],[1,1.06],clamp)}}/></Sequence>
<Sequence name="Help is here" from={20*fps} durationInFrames={6*fps} premountFor={fps}><CanvasImage src={staticFile('hell.jpg')} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'cover',scale:interpolate(f,[20*fps,26*fps],[1,1.06],clamp)}}/></Sequence>
<Sequence name="Invitation" from={26*fps} durationInFrames={5.5*fps} premountFor={fps}><CanvasImage src={staticFile('alex.jpg')} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'cover',scale:interpolate(f,[26*fps,31.5*fps],[1,1.06],clamp)}}/></Sequence>
<AbsoluteFill style={{background:'linear-gradient(180deg,rgba(6,14,24,.12),rgba(6,14,24,.05) 45%,rgba(4,8,12,.86))'}}/>
<AbsoluteFill style={{background:'#bd843a',mixBlendMode:'soft-light',opacity:interpolate(f,[18*fps,24*fps],[0,.32],clamp)}}/>
<AbsoluteFill style={{boxShadow:'inset 0 0 180px 60px rgba(0,0,0,.5)'}}/>
<AbsoluteFill style={{height:54,background:'#07090a'}}/><AbsoluteFill style={{top:'auto',height:54,background:'#07090a'}}/>
<Sequence name="Script 1" from={0.8*fps} durationInFrames={2.700*fps} premountFor={fps}><Words>Have you seen this scene from Madagascar,</Words></Sequence>
<Sequence name="Script 2" from={3.5*fps} durationInFrames={2.500*fps} premountFor={fps}><Words>where Alex tries to spell HELP,</Words></Sequence>
<Sequence name="Script 3" from={6*fps} durationInFrames={3.000*fps} premountFor={fps}><Words>but it suddenly turns into HELL?</Words></Sequence>
<Sequence name="Script 4" from={9*fps} durationInFrames={4.500*fps} premountFor={fps}><Words>What if I told you there’s a deeper message here?</Words></Sequence>
<Sequence name="Script 5" from={13.5*fps} durationInFrames={3.000*fps} premountFor={fps}><Words>Jesus came to rescue us from sin</Words></Sequence>
<Sequence name="Script 6" from={16.5*fps} durationInFrames={3.500*fps} premountFor={fps}><Words>and eternal separation from God.</Words></Sequence>
<Sequence name="Script 7" from={20*fps} durationInFrames={3.000*fps} premountFor={fps}><Words large accent>The HELP is already here.</Words></Sequence>
<Sequence name="Script 8" from={23*fps} durationInFrames={3.000*fps} premountFor={fps}><Words large accent>His name is JESUS.</Words></Sequence>
<Sequence name="Script 9" from={26*fps} durationInFrames={5.500*fps} premountFor={fps}><Words large>The question is…<br/>will you accept Him?</Words></Sequence>
<Audio name="Cinematic piano and pad" src={staticFile("score.wav")} volume={.4} premountFor={fps}/>
<Audio name="Soft American female 1" src={staticFile("voice-0.wav")} from={0.8*fps} premountFor={fps}/>
<Audio name="Soft American female 2" src={staticFile("voice-1.wav")} from={3.5*fps} premountFor={fps}/>
<Audio name="Soft American female 3" src={staticFile("voice-2.wav")} from={6*fps} premountFor={fps}/>
<Audio name="Soft American female 4" src={staticFile("voice-3.wav")} from={9*fps} premountFor={fps}/>
<Audio name="Soft American female 5" src={staticFile("voice-4.wav")} from={13.5*fps} premountFor={fps}/>
<Audio name="Soft American female 6" src={staticFile("voice-5.wav")} from={16.5*fps} premountFor={fps}/>
<Audio name="Soft American female 7" src={staticFile("voice-6.wav")} from={20*fps} premountFor={fps}/>
<Audio name="Soft American female 8" src={staticFile("voice-7.wav")} from={23*fps} premountFor={fps}/>
<Audio name="Soft American female 9" src={staticFile("voice-8.wav")} from={26*fps} premountFor={fps}/>
<AbsoluteFill style={{background:'#000',opacity:Math.max(interpolate(f,[0,15],[1,0],clamp),interpolate(f,[30*fps,31.5*fps-1],[0,1],clamp))}}/>
</AbsoluteFill>};
export const RemotionRoot=()=> <Composition id="HelpIsHere" component={Gospel} durationInFrames={945} fps={30} width={1920} height={1080}/>;
