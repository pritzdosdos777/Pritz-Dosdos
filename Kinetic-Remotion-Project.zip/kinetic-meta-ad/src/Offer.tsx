import { Camera, Title, WordCaptions, brand } from "./Design";
export const Offer = () => (
  <>
    <Camera trimBefore={339} durationInFrames={111} zoom={1.04} />
    <Title eyebrow="FOR NEW AUTO ACCIDENT PATIENTS">
      <span style={{ color: brand.mint }}>Free</span>
      <br />
      consultation.
    </Title>
    <WordCaptions
      captions={[
        {
          text: " We",
          startMs: 20,
          endMs: 200,
          timestampMs: 20,
          confidence: 0.995649516582489,
        },
        {
          text: " offer",
          startMs: 200,
          endMs: 420,
          timestampMs: 200,
          confidence: 0.9987969398498535,
        },
        {
          text: " a",
          startMs: 420,
          endMs: 720,
          timestampMs: 420,
          confidence: 0.9354497194290161,
        },
        {
          text: " free",
          startMs: 720,
          endMs: 940,
          timestampMs: 720,
          confidence: 0.9914054870605469,
        },
        {
          text: " consultation",
          startMs: 940,
          endMs: 1540,
          timestampMs: 940,
          confidence: 0.995595395565033,
        },
        {
          text: " for",
          startMs: 1540,
          endMs: 2080,
          timestampMs: 1540,
          confidence: 0.9932017922401428,
        },
        {
          text: " new",
          startMs: 2080,
          endMs: 2240,
          timestampMs: 2080,
          confidence: 0.9977363348007202,
        },
        {
          text: " patients",
          startMs: 2240,
          endMs: 2640,
          timestampMs: 2240,
          confidence: 0.9664099812507629,
        },
        {
          text: " after",
          startMs: 2640,
          endMs: 3000,
          timestampMs: 2640,
          confidence: 0.9867954254150391,
        },
        {
          text: " a",
          startMs: 3000,
          endMs: 3140,
          timestampMs: 3000,
          confidence: 0.993131697177887,
        },
        {
          text: " car",
          startMs: 3140,
          endMs: 3280,
          timestampMs: 3140,
          confidence: 0.9978914856910706,
        },
        {
          text: " accident.",
          startMs: 3280,
          endMs: 3560,
          timestampMs: 3280,
          confidence: 0.9996540546417236,
        },
      ]}
    />
  </>
);
