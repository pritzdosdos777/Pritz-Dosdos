import { Camera, Title, WordCaptions, brand } from "./Design";
export const Book = () => (
  <>
    <Camera trimBefore={1203} durationInFrames={195} zoom={1.06} />
    <Title eyebrow="TAKE THE FIRST STEP">
      <span style={{ color: brand.mint }}>Tap below.</span>
      <br />
      <span style={{ fontSize: 75 }}>Request a visit.</span>
      <div
        style={{
          fontSize: 35,
          fontWeight: 600,
          letterSpacing: 0,
          lineHeight: 1.4,
          marginTop: 25,
        }}
      >
        Fill out the short form.
        <br />
        Choose your appointment time.
      </div>
      <div
        style={{
          fontSize: 28,
          fontWeight: 550,
          letterSpacing: 0,
          marginTop: 22,
        }}
      >
        No payment to request a free consultation.
      </div>
    </Title>
    <WordCaptions
      captions={[
        {
          text: " Tap",
          startMs: 80,
          endMs: 200,
          timestampMs: 80,
          confidence: 0.9879429936408997,
        },
        {
          text: " below,",
          startMs: 200,
          endMs: 620,
          timestampMs: 200,
          confidence: 0.8979844450950623,
        },
        {
          text: " fill",
          startMs: 880,
          endMs: 1000,
          timestampMs: 880,
          confidence: 0.9908825755119324,
        },
        {
          text: " out",
          startMs: 1000,
          endMs: 1180,
          timestampMs: 1000,
          confidence: 0.998584508895874,
        },
        {
          text: " the",
          startMs: 1180,
          endMs: 1340,
          timestampMs: 1180,
          confidence: 0.9961793422698975,
        },
        {
          text: " short",
          startMs: 1340,
          endMs: 1460,
          timestampMs: 1340,
          confidence: 0.9916084408760071,
        },
        {
          text: " form",
          startMs: 1460,
          endMs: 1880,
          timestampMs: 1460,
          confidence: 0.8659766316413879,
        },
        {
          text: " and",
          startMs: 1880,
          endMs: 2160,
          timestampMs: 1880,
          confidence: 0.5799669027328491,
        },
        {
          text: " choose",
          startMs: 2160,
          endMs: 2460,
          timestampMs: 2160,
          confidence: 0.9916714429855347,
        },
        {
          text: " your",
          startMs: 2460,
          endMs: 2640,
          timestampMs: 2460,
          confidence: 0.9967743754386902,
        },
        {
          text: " appointment",
          startMs: 2640,
          endMs: 2880,
          timestampMs: 2640,
          confidence: 0.9957113265991211,
        },
        {
          text: " time.",
          startMs: 2880,
          endMs: 3320,
          timestampMs: 2880,
          confidence: 0.9911223649978638,
        },
        {
          text: " No",
          startMs: 3780,
          endMs: 3960,
          timestampMs: 3780,
          confidence: 0.9752745032310486,
        },
        {
          text: " payment",
          startMs: 3960,
          endMs: 4220,
          timestampMs: 3960,
          confidence: 0.995154619216919,
        },
        {
          text: " is",
          startMs: 4220,
          endMs: 4380,
          timestampMs: 4220,
          confidence: 0.9407675862312317,
        },
        {
          text: " required",
          startMs: 4380,
          endMs: 4580,
          timestampMs: 4380,
          confidence: 0.9989035129547119,
        },
        {
          text: " to",
          startMs: 4580,
          endMs: 4820,
          timestampMs: 4580,
          confidence: 0.9968675971031189,
        },
        {
          text: " request",
          startMs: 4820,
          endMs: 5120,
          timestampMs: 4820,
          confidence: 0.9813668727874756,
        },
        {
          text: " your",
          startMs: 5120,
          endMs: 5600,
          timestampMs: 5120,
          confidence: 0.9966512322425842,
        },
        {
          text: " free",
          startMs: 5600,
          endMs: 5880,
          timestampMs: 5600,
          confidence: 0.9914901852607727,
        },
        {
          text: " consultation.",
          startMs: 5880,
          endMs: 6360,
          timestampMs: 5880,
          confidence: 0.9981369972229004,
        },
      ]}
    />
  </>
);
