import { Camera, Title, WordCaptions, Benefit } from "./Design";
export const Listen = () => (
  <>
    <Camera trimBefore={462} durationInFrames={153} zoom={1.12} />
    <Title eyebrow="MEET DIRECTLY WITH DR. ANDREW">
      <span style={{ fontSize: 65 }}>Let’s talk about it.</span>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 20,
          marginTop: 30,
        }}
      >
        <Benefit label="What happened" from={25} />
        <Benefit label="Your symptoms" from={70} />
        <Benefit label="Your care options" from={112} />
      </div>
    </Title>
    <WordCaptions
      captions={[
        {
          text: " You'll",
          startMs: 60,
          endMs: 160,
          timestampMs: 60,
          confidence: 0.9943833351135254,
        },
        {
          text: " meet",
          startMs: 160,
          endMs: 400,
          timestampMs: 160,
          confidence: 0.9991044402122498,
        },
        {
          text: " directly",
          startMs: 400,
          endMs: 660,
          timestampMs: 400,
          confidence: 0.9976173043251038,
        },
        {
          text: " with",
          startMs: 660,
          endMs: 920,
          timestampMs: 660,
          confidence: 0.9992732405662537,
        },
        {
          text: " me.",
          startMs: 920,
          endMs: 1240,
          timestampMs: 920,
          confidence: 0.9978099465370178,
        },
        {
          text: " discuss",
          startMs: 1400,
          endMs: 1740,
          timestampMs: 1400,
          confidence: 0.9992678761482239,
        },
        {
          text: " what",
          startMs: 1740,
          endMs: 1980,
          timestampMs: 1740,
          confidence: 0.9892703294754028,
        },
        {
          text: " happened,",
          startMs: 1980,
          endMs: 2380,
          timestampMs: 1980,
          confidence: 0.8651604652404785,
        },
        {
          text: " review",
          startMs: 2560,
          endMs: 2660,
          timestampMs: 2560,
          confidence: 0.9845369458198547,
        },
        {
          text: " your",
          startMs: 2660,
          endMs: 2960,
          timestampMs: 2660,
          confidence: 0.9987188577651978,
        },
        {
          text: " symptoms,",
          startMs: 2960,
          endMs: 3260,
          timestampMs: 2960,
          confidence: 0.99702388048172,
        },
        {
          text: " talk",
          startMs: 3780,
          endMs: 3940,
          timestampMs: 3780,
          confidence: 0.991605281829834,
        },
        {
          text: " through",
          startMs: 3940,
          endMs: 4200,
          timestampMs: 3940,
          confidence: 0.905562162399292,
        },
        {
          text: " your",
          startMs: 4200,
          endMs: 4320,
          timestampMs: 4200,
          confidence: 0.9962623715400696,
        },
        {
          text: " care",
          startMs: 4320,
          endMs: 4500,
          timestampMs: 4320,
          confidence: 0.9823526740074158,
        },
        {
          text: " options.",
          startMs: 4500,
          endMs: 4940,
          timestampMs: 4500,
          confidence: 0.9988723397254944,
        },
      ]}
    />
  </>
);
