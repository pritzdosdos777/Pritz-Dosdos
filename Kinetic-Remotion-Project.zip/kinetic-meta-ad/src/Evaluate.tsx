import { Camera, Title, WordCaptions, brand } from "./Design";
export const Evaluate = () => (
  <>
    <Camera trimBefore={627} durationInFrames={165} zoom={1.04} />
    <Title eyebrow="UNDERSTAND THE NEXT STEP">
      <span style={{ fontSize: 77 }}>
        An evaluation.
        <br />
        <span style={{ color: brand.mint }}>A plan for you.</span>
      </span>
      <div
        style={{
          fontSize: 35,
          fontWeight: 550,
          letterSpacing: 0,
          marginTop: 30,
          lineHeight: 1.35,
        }}
      >
        Assess movement · Discuss care
      </div>
    </Title>
    <WordCaptions
      captions={[
        {
          text: " Your",
          startMs: 80,
          endMs: 180,
          timestampMs: 80,
          confidence: 0.9926859140396118,
        },
        {
          text: " care",
          startMs: 180,
          endMs: 420,
          timestampMs: 180,
          confidence: 0.9785690307617188,
        },
        {
          text: " starts",
          startMs: 420,
          endMs: 960,
          timestampMs: 420,
          confidence: 0.9928361773490906,
        },
        {
          text: " with",
          startMs: 960,
          endMs: 1340,
          timestampMs: 960,
          confidence: 0.9925618767738342,
        },
        {
          text: " an",
          startMs: 1340,
          endMs: 1400,
          timestampMs: 1340,
          confidence: 0.9958772659301758,
        },
        {
          text: " evaluation.",
          startMs: 1400,
          endMs: 1940,
          timestampMs: 1400,
          confidence: 0.998548686504364,
        },
        {
          text: " I'll",
          startMs: 2280,
          endMs: 2420,
          timestampMs: 2280,
          confidence: 0.9961472153663635,
        },
        {
          text: " check",
          startMs: 2420,
          endMs: 2580,
          timestampMs: 2420,
          confidence: 0.9966611862182617,
        },
        {
          text: " how",
          startMs: 2580,
          endMs: 2800,
          timestampMs: 2580,
          confidence: 0.99594646692276,
        },
        {
          text: " you're",
          startMs: 2800,
          endMs: 2920,
          timestampMs: 2800,
          confidence: 0.9833044409751892,
        },
        {
          text: " moving",
          startMs: 2920,
          endMs: 3180,
          timestampMs: 2920,
          confidence: 0.9992259740829468,
        },
        {
          text: " and",
          startMs: 3180,
          endMs: 3400,
          timestampMs: 3180,
          confidence: 0.9366430640220642,
        },
        {
          text: " explain",
          startMs: 3400,
          endMs: 3740,
          timestampMs: 3400,
          confidence: 0.9971764087677002,
        },
        {
          text: " which",
          startMs: 3740,
          endMs: 4080,
          timestampMs: 3740,
          confidence: 0.9971079230308533,
        },
        {
          text: " steps",
          startMs: 4080,
          endMs: 4420,
          timestampMs: 4080,
          confidence: 0.9985735416412354,
        },
        {
          text: " fit",
          startMs: 4420,
          endMs: 4880,
          timestampMs: 4420,
          confidence: 0.2811353802680969,
        },
        {
          text: " your",
          startMs: 4880,
          endMs: 5040,
          timestampMs: 4880,
          confidence: 0.495707243680954,
        },
        {
          text: " needs.",
          startMs: 5040,
          endMs: 5380,
          timestampMs: 5040,
          confidence: 0.9742516875267029,
        },
      ]}
    />
  </>
);
