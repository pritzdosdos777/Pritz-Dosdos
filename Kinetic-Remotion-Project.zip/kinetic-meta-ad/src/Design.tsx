import {
  AbsoluteFill,
  CanvasImage,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import { Video } from "@remotion/media";
import type { Caption } from "@remotion/captions";

export const brand = {
  navy: "#062A3A",
  teal: "#247C88",
  mint: "#A9DDAF",
  cream: "#F4F7F2",
};
export const font = "Montserrat, sans-serif";

export const Camera = ({
  trimBefore,
  durationInFrames,
  zoom = 1,
}: {
  trimBefore: number;
  durationInFrames: number;
  zoom?: number;
}) => {
  const f = useCurrentFrame();
  return (
    <>
      <Video
        name="Dr. Andrew — original footage and voice"
        src={staticFile("kinetic-source.mp4")}
        trimBefore={trimBefore}
        durationInFrames={durationInFrames}
        objectFit="cover"
        style={{
          width: "100%",
          height: "100%",
          scale: interpolate(f, [0, durationInFrames], [zoom, zoom + 0.025], {
            extrapolateRight: "clamp",
          }),
          transformOrigin: "50% 36%",
        }}
      />
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(180deg, rgba(6,42,58,.3) 0%,transparent 35%,transparent 42%,rgba(6,42,58,.88) 72%,#062A3A 100%)",
        }}
      />
      <CanvasImage
        name="Kinetic logo"
        src={staticFile("kinetic-logo.png")}
        style={{
          position: "absolute",
          top: 150,
          left: 90,
          width: 250,
          height: 190,
          objectFit: "contain",
          background: brand.cream,
          padding: 16,
          borderRadius: 16,
        }}
      />
      <Interactive.Div
        name="Location"
        style={{
          position: "absolute",
          top: 214,
          right: 108,
          fontFamily: font,
          fontSize: 30,
          fontWeight: 700,
          color: "white",
          letterSpacing: 3,
          textAlign: "right",
          lineHeight: 1.5,
        }}
      >
        PLEASANT GROVE
        <br />
        UTAH
      </Interactive.Div>
    </>
  );
};

export const Title = ({
  eyebrow,
  children,
}: {
  eyebrow?: string;
  children: React.ReactNode;
}) => {
  const f = useCurrentFrame();
  return (
    <Interactive.Div
      name="Scene headline"
      style={{
        position: "absolute",
        left: 92,
        top: 1030,
        width: 850,
        color: "white",
        fontFamily: font,
        opacity: interpolate(f, [0, 7], [0, 1], { extrapolateRight: "clamp" }),
        translate: interpolate(f, [0, 12], ["0px 35px", "0px 0px"], {
          extrapolateRight: "clamp",
        }),
      }}
    >
      {eyebrow ? (
        <div
          style={{
            fontSize: 30,
            fontWeight: 700,
            letterSpacing: 4,
            color: brand.mint,
            marginBottom: 24,
          }}
        >
          {eyebrow}
        </div>
      ) : null}
      <div
        style={{
          fontSize: 86,
          fontWeight: 850,
          lineHeight: 1.02,
          letterSpacing: -3,
        }}
      >
        {children}
      </div>
    </Interactive.Div>
  );
};

export const WordCaptions = ({ captions }: { captions: Caption[] }) => {
  const f = useCurrentFrame();
  const ms = (f / 30) * 1000;
  const pages: Caption[][] = [];
  let row: Caption[] = [];
  for (const word of captions) {
    if (
      row.length &&
      (row.length >= 5 ||
        row.map((w) => w.text).join("").length + word.text.length > 31 ||
        word.startMs - row[row.length - 1].endMs > 350)
    ) {
      pages.push(row);
      row = [];
    }
    row.push(word);
    if (/[.!?]$/.test(word.text.trim())) {
      pages.push(row);
      row = [];
    }
  }
  if (row.length) pages.push(row);
  const active = pages.find(
    (p) =>
      ms >= p[0].startMs - 40 &&
      ms < Math.max(p[p.length - 1].endMs + 120, p[0].startMs + 400),
  );
  if (!active) return null;
  return (
    <Interactive.Div
      name="Word-synced captions"
      style={{
        position: "absolute",
        left: 90,
        width: 860,
        top: 1490,
        textAlign: "center",
        fontFamily: font,
        fontSize: 57,
        fontWeight: 850,
        lineHeight: 1.18,
        textTransform: "uppercase",
        textShadow: "0 3px 16px rgba(0,0,0,.45)",
      }}
    >
      {active.map((w, i) => (
        <span
          key={i}
          style={{
            color: ms >= w.startMs && ms < w.endMs + 30 ? brand.mint : "white",
          }}
        >
          {w.text}
        </span>
      ))}
    </Interactive.Div>
  );
};

export const Tick = () => (
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
    <circle cx="24" cy="24" r="23" fill={brand.mint} />
    <path
      d="m13 24 8 8 15-17"
      stroke={brand.navy}
      strokeWidth="4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const Benefit = ({
  label,
  from = 0,
}: {
  label: string;
  from?: number;
}) => {
  const f = useCurrentFrame();
  return (
    <div
      style={{
        display: "flex",
        gap: 22,
        alignItems: "center",
        fontSize: 43,
        fontWeight: 700,
        opacity: interpolate(f, [from, from + 8], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
        translate: interpolate(f, [from, from + 12], ["30px 0px", "0px 0px"], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
      }}
    >
      <Tick />
      {label}
    </div>
  );
};
