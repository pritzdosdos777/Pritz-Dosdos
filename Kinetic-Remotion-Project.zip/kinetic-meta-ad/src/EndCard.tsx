import {
  AbsoluteFill,
  CanvasImage,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import { brand, font } from "./Design";

export const EndCard = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: brand.cream,
        color: brand.navy,
        fontFamily: font,
        alignItems: "center",
      }}
    >
      <div
        style={{
          position: "absolute",
          width: 800,
          height: 800,
          top: 380,
          border: "1px solid #247C8822",
          borderRadius: "50%",
          scale: interpolate(f, [0, 90], [0.9, 1.1]),
        }}
      />
      <CanvasImage
        name="Official brand logo"
        src={staticFile("kinetic-logo.png")}
        style={{
          position: "absolute",
          width: 420,
          height: 320,
          objectFit: "contain",
          top: 240,
        }}
      />
      <Interactive.Div
        name="Brand promise"
        style={{
          position: "absolute",
          top: 650,
          width: 900,
          textAlign: "center",
          fontWeight: 850,
          fontSize: 90,
          lineHeight: 1.06,
          letterSpacing: -3,
        }}
      >
        Move freely.
        <br />
        <span style={{ color: brand.teal }}>Live fully.</span>
      </Interactive.Div>
      <Interactive.Div
        name="Free consultation CTA"
        style={{
          position: "absolute",
          top: 985,
          width: 870,
          textAlign: "center",
          padding: "40px 26px",
          borderRadius: 24,
          background: brand.navy,
          color: "white",
          fontSize: 48,
          fontWeight: 800,
          opacity: interpolate(f, [0, 10], [0, 1], {
            extrapolateRight: "clamp",
          }),
          translate: interpolate(f, [0, 12], ["0px 25px", "0px 0px"], {
            extrapolateRight: "clamp",
          }),
        }}
      >
        REQUEST A FREE
        <br />
        <span style={{ color: brand.mint }}>CONSULTATION ↗</span>
      </Interactive.Div>
      <div
        style={{
          position: "absolute",
          top: 1200,
          fontSize: 39,
          fontWeight: 650,
        }}
      >
        Pleasant Grove, Utah
      </div>
      <div
        style={{
          position: "absolute",
          top: 1280,
          fontSize: 47,
          fontWeight: 800,
        }}
      >
        (385) 256-0603
      </div>
      <div
        style={{
          position: "absolute",
          top: 1380,
          fontSize: 33,
          fontWeight: 600,
        }}
      >
        kineticchiropracticutah.com
      </div>
      <div
        style={{
          position: "absolute",
          top: 1510,
          fontSize: 30,
          color: brand.teal,
        }}
      >
        Consultation is free. Exam and treatment fees apply.
      </div>
    </AbsoluteFill>
  );
};
