import { Camera, Title, WordCaptions, brand } from "./Design";
export const Doctor = () => (
  <>
    <Camera trimBefore={240} durationInFrames={90} zoom={1.13} />
    <Title eyebrow="MEET YOUR CHIROPRACTOR">
      <span style={{ fontSize: 64 }}>Dr. Andrew</span>
      <br />
      <span style={{ fontSize: 70, color: brand.mint }}>Kakishita</span>
    </Title>
    <WordCaptions
      captions={[
        {
          text: " I'm",
          startMs: 0,
          endMs: 160,
          timestampMs: 0,
          confidence: 0.9792552888393402,
        },
        {
          text: " Dr.",
          startMs: 160,
          endMs: 420,
          timestampMs: 160,
          confidence: 0.9312952160835266,
        },
        {
          text: " Andrew",
          startMs: 500,
          endMs: 680,
          timestampMs: 500,
          confidence: 0.9884601831436157,
        },
        {
          text: " Kakishita",
          startMs: 680,
          endMs: 1160,
          timestampMs: 680,
          confidence: 0.27216616086661816,
        },
        {
          text: " with",
          startMs: 1160,
          endMs: 1400,
          timestampMs: 1160,
          confidence: 0.9638966917991638,
        },
        {
          text: " Kinetic",
          startMs: 1400,
          endMs: 1560,
          timestampMs: 1400,
          confidence: 0.9808284938335419,
        },
        {
          text: " Chiropractic",
          startMs: 1560,
          endMs: 2100,
          timestampMs: 1560,
          confidence: 0.9962122887372971,
        },
        {
          text: " here",
          startMs: 2100,
          endMs: 2240,
          timestampMs: 2100,
          confidence: 0.24672500789165497,
        },
        {
          text: " in",
          startMs: 2240,
          endMs: 2340,
          timestampMs: 2240,
          confidence: 0.7867506146430969,
        },
        {
          text: " Pleasant",
          startMs: 2340,
          endMs: 2520,
          timestampMs: 2340,
          confidence: 0.9958449006080627,
        },
        {
          text: " Grove.",
          startMs: 2520,
          endMs: 2860,
          timestampMs: 2520,
          confidence: 0.9973680377006531,
        },
      ]}
    />
  </>
);
