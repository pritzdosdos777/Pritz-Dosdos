import {
  AbsoluteFill,
  Composition,
  Folder,
  Series,
  staticFile,
  useCurrentFrame,
  interpolate,
  useVideoConfig,
} from "remotion";
import { Audio } from "@remotion/media";
import { Hook } from "./Hook";
import { Doctor } from "./Doctor";
import { Offer } from "./Offer";
import { Listen } from "./Listen";
import { Evaluate } from "./Evaluate";
import { Benefits } from "./Benefits";
import { Book } from "./Book";
import { EndCard } from "./EndCard";
import { brand } from "./Design";

const Music = () => {
  const f = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return (
    <Audio
      name="Original music bed"
      src={staticFile("music.wav")}
      volume={interpolate(
        f,
        [0, 25, durationInFrames - 35, durationInFrames],
        [0, 0.075, 0.075, 0],
        { extrapolateRight: "clamp" },
      )}
    />
  );
};

export const KineticAd = () => (
  <AbsoluteFill style={{ background: brand.navy }}>
    <Series name="40-second Meta ad">
      <Series.Sequence
        name="Hook — care starts with listening"
        durationInFrames={135}
      >
        <Hook />
      </Series.Sequence>
      <Series.Sequence name="Meet Dr. Andrew" durationInFrames={90}>
        <Doctor />
      </Series.Sequence>
      <Series.Sequence name="Free consultation" durationInFrames={111}>
        <Offer />
      </Series.Sequence>
      <Series.Sequence name="Listen and discuss options" durationInFrames={153}>
        <Listen />
      </Series.Sequence>
      <Series.Sequence name="Evaluation and next steps" durationInFrames={165}>
        <Evaluate />
      </Series.Sequence>
      <Series.Sequence
        name="Utah PIP and eligible billing"
        durationInFrames={252}
      >
        <Benefits />
      </Series.Sequence>
      <Series.Sequence name="Request an appointment" durationInFrames={195}>
        <Book />
      </Series.Sequence>
      <Series.Sequence name="Brand and booking end card" durationInFrames={99}>
        <EndCard />
      </Series.Sequence>
    </Series>
    <Music />
  </AbsoluteFill>
);

export const KineticShortAd = () => (
  <AbsoluteFill style={{ background: brand.navy }}>
    <Series name="30-second Meta ad">
      <Series.Sequence name="Hook" durationInFrames={135}>
        <Hook />
      </Series.Sequence>
      <Series.Sequence name="Free consultation" durationInFrames={111}>
        <Offer />
      </Series.Sequence>
      <Series.Sequence
        name="Meet directly — discuss symptoms"
        durationInFrames={102}
      >
        <Listen />
      </Series.Sequence>
      <Series.Sequence
        name="Utah PIP and eligible billing"
        durationInFrames={252}
      >
        <Benefits />
      </Series.Sequence>
      <Series.Sequence name="Request an appointment" durationInFrames={195}>
        <Book />
      </Series.Sequence>
      <Series.Sequence name="Booking end card" durationInFrames={105}>
        <EndCard />
      </Series.Sequence>
    </Series>
    <Music />
  </AbsoluteFill>
);

export const RemotionRoot = () => (
  <>
    <Composition
      id="Kinetic-Meta-Ad-40s"
      component={KineticAd}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={1200}
    />
    <Composition
      id="Kinetic-Meta-Ad-30s"
      component={KineticShortAd}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={900}
    />
    <Folder name="Editable-Scenes">
      <Composition
        id="Hook"
        component={Hook}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={135}
      />
      <Composition
        id="Doctor"
        component={Doctor}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={90}
      />
      <Composition
        id="Offer"
        component={Offer}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={111}
      />
      <Composition
        id="Listen"
        component={Listen}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={153}
      />
      <Composition
        id="Evaluate"
        component={Evaluate}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={165}
      />
      <Composition
        id="Benefits"
        component={Benefits}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={252}
      />
      <Composition
        id="Book"
        component={Book}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={195}
      />
      <Composition
        id="EndCard"
        component={EndCard}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={105}
      />
    </Folder>
  </>
);
