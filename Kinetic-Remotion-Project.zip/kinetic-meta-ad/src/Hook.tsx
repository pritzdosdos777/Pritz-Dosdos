import { Camera, Title, WordCaptions, brand } from "./Design";
export const Hook = () => (
  <>
    <Camera trimBefore={0} durationInFrames={135} zoom={1.06} />
    <Title eyebrow="AUTO ACCIDENT CARE">
      Care starts
      <br />
      with <span style={{ color: brand.mint }}>listening.</span>
    </Title>
    <WordCaptions
      captions={[
        {
          text: " After",
          startMs: 0,
          endMs: 920,
          timestampMs: 0,
          confidence: 0.8649213314056396,
        },
        {
          text: " a",
          startMs: 920,
          endMs: 1060,
          timestampMs: 920,
          confidence: 0.9768462777137756,
        },
        {
          text: " car",
          startMs: 1060,
          endMs: 1220,
          timestampMs: 1060,
          confidence: 0.8905469179153442,
        },
        {
          text: " accident,",
          startMs: 1220,
          endMs: 1480,
          timestampMs: 1220,
          confidence: 0.9778252243995667,
        },
        {
          text: " getting",
          startMs: 1580,
          endMs: 1800,
          timestampMs: 1580,
          confidence: 0.9509618878364563,
        },
        {
          text: " checked",
          startMs: 1800,
          endMs: 2120,
          timestampMs: 1800,
          confidence: 0.9475204348564148,
        },
        {
          text: " starts",
          startMs: 2120,
          endMs: 2440,
          timestampMs: 2120,
          confidence: 0.9900175929069519,
        },
        {
          text: " with",
          startMs: 2440,
          endMs: 2700,
          timestampMs: 2440,
          confidence: 0.9861650466918945,
        },
        {
          text: " someone",
          startMs: 2700,
          endMs: 2920,
          timestampMs: 2700,
          confidence: 0.9966683983802795,
        },
        {
          text: " taking",
          startMs: 2920,
          endMs: 3180,
          timestampMs: 2920,
          confidence: 0.9895879030227661,
        },
        {
          text: " the",
          startMs: 3180,
          endMs: 3340,
          timestampMs: 3180,
          confidence: 0.9838792085647583,
        },
        {
          text: " time",
          startMs: 3340,
          endMs: 3620,
          timestampMs: 3340,
          confidence: 0.9987706542015076,
        },
        {
          text: " to",
          startMs: 3620,
          endMs: 3840,
          timestampMs: 3620,
          confidence: 0.9976217150688171,
        },
        {
          text: " listen.",
          startMs: 3840,
          endMs: 4280,
          timestampMs: 3840,
          confidence: 0.9950357675552368,
        },
      ]}
    />
  </>
);
