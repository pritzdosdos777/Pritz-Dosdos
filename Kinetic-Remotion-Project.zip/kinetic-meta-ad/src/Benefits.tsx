import { Camera, Title, WordCaptions, brand } from "./Design";
export const Benefits = () => (
  <>
    <Camera trimBefore={804} durationInFrames={252} zoom={1.1} />
    <Title eyebrow="WE HELP EXPLAIN YOUR OPTIONS">
      <span style={{ color: brand.mint }}>Utah PIP</span>
      <br />
      benefits.
      <div
        style={{
          fontSize: 35,
          fontWeight: 600,
          letterSpacing: 0,
          lineHeight: 1.4,
          marginTop: 25,
        }}
      >
        Eligible accident-related care
        <br />
        billed directly to auto insurance.
      </div>
      <div
        style={{
          fontSize: 25,
          fontWeight: 500,
          letterSpacing: 0,
          marginTop: 20,
          opacity: 0.75,
        }}
      >
        Coverage and eligibility vary.
      </div>
    </Title>
    <WordCaptions
      captions={[
        {
          text: " We'll",
          startMs: 60,
          endMs: 200,
          timestampMs: 60,
          confidence: 0.8947423696517944,
        },
        {
          text: " also",
          startMs: 200,
          endMs: 460,
          timestampMs: 200,
          confidence: 0.9975571632385254,
        },
        {
          text: " help",
          startMs: 460,
          endMs: 720,
          timestampMs: 460,
          confidence: 0.4570406973361969,
        },
        {
          text: " you",
          startMs: 720,
          endMs: 900,
          timestampMs: 720,
          confidence: 0.9935196042060852,
        },
        {
          text: " understand",
          startMs: 900,
          endMs: 1400,
          timestampMs: 900,
          confidence: 0.9868109822273254,
        },
        {
          text: " whether",
          startMs: 1400,
          endMs: 1860,
          timestampMs: 1400,
          confidence: 0.9916231036186218,
        },
        {
          text: " your",
          startMs: 1860,
          endMs: 2280,
          timestampMs: 1860,
          confidence: 0.9532414674758911,
        },
        {
          text: " Utah",
          startMs: 2280,
          endMs: 2600,
          timestampMs: 2280,
          confidence: 0.7102609276771545,
        },
        {
          text: " PIP",
          startMs: 2600,
          endMs: 2980,
          timestampMs: 2600,
          confidence: 0.6388218104839325,
        },
        {
          text: " benefits",
          startMs: 2980,
          endMs: 3180,
          timestampMs: 2980,
          confidence: 0.10410668700933456,
        },
        {
          text: " apply.",
          startMs: 3180,
          endMs: 3740,
          timestampMs: 3180,
          confidence: 0.004761040210723877,
        },
        {
          text: " Our",
          startMs: 4380,
          endMs: 4560,
          timestampMs: 4380,
          confidence: 0.9806841015815735,
        },
        {
          text: " office",
          startMs: 4560,
          endMs: 4840,
          timestampMs: 4560,
          confidence: 0.6256054639816284,
        },
        {
          text: " bills",
          startMs: 4840,
          endMs: 5120,
          timestampMs: 4840,
          confidence: 0.5043206810951233,
        },
        {
          text: " eligible",
          startMs: 5120,
          endMs: 5540,
          timestampMs: 5120,
          confidence: 0.956121563911438,
        },
        {
          text: " accident",
          startMs: 5540,
          endMs: 6000,
          timestampMs: 5540,
          confidence: 0.8687069416046143,
        },
        {
          text: " related",
          startMs: 6000,
          endMs: 6360,
          timestampMs: 6000,
          confidence: 0.8118535280227661,
        },
        {
          text: " care",
          startMs: 6360,
          endMs: 6740,
          timestampMs: 6360,
          confidence: 0.9413036108016968,
        },
        {
          text: " directly",
          startMs: 6740,
          endMs: 7140,
          timestampMs: 6740,
          confidence: 0.9046273231506348,
        },
        {
          text: " to",
          startMs: 7140,
          endMs: 7660,
          timestampMs: 7140,
          confidence: 0.9963847398757935,
        },
        {
          text: " auto",
          startMs: 7660,
          endMs: 7820,
          timestampMs: 7660,
          confidence: 0.9278668761253357,
        },
        {
          text: " insurance.",
          startMs: 7820,
          endMs: 8300,
          timestampMs: 7820,
          confidence: 0.9712668061256409,
        },
      ]}
    />
  </>
);
