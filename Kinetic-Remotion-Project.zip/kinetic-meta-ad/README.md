# Kinetic Chiropractic — Meta ad edits

Two editable vertical Remotion compositions, based on Kinetic Chiro 1.mov and the Sierra Example.mov editing reference.

- **Kinetic-Meta-Ad-40s**: full edit with doctor introduction, consultation, evaluation, PIP benefits and booking CTA.
- **Kinetic-Meta-Ad-30s**: tighter cut with the consultation offer, listening, PIP benefits and booking CTA.
- Both are 1080 × 1920, 30 fps.

## Open and edit

Install Node.js 22 or later, then run:

```sh
npm install
npm run dev -- --no-open
```

Open the Studio URL printed in the terminal. Choose either main composition. The Editable-Scenes folder contains each scene's own timeline. Speech captions are inline arrays in the scene source files. Brand colors, caption style and camera treatment are in src/Design.tsx. Contact details and the booking message are in src/EndCard.tsx.

## Export when ready

Use Studio's Render button, or:

```sh
npx remotion render src/index.ts Kinetic-Meta-Ad-40s kinetic-meta-ad-40s.mp4 --codec=h264
npx remotion render src/index.ts Kinetic-Meta-Ad-30s kinetic-meta-ad-30s.mp4 --codec=h264
```

The project ships without a machine-specific Chromium path. Remotion downloads its supported browser when needed.

## Editorial notes

The repeated introduction and closing sign-off were removed. The original doctor footage and voice are retained. Added elements include navy/teal/mint branding, animated headlines, word-synced highlighted captions, punch-ins, staggered checklist graphics and a booking end card. Music is an original synthesized bed created for this edit. The source footage is 480 × 854; the 1080 × 1920 composition enlarges it.

The logo was prepared as a transparent image using the supplied visual reference, which had no downloadable attachment path. For exact original-pixel fidelity, replace public/kinetic-logo.png with the original PNG. No image from the Sierra reference is reused.

Clinic name, location, phone number, tagline and consultation offer were checked against https://www.kineticchiropracticutah.com/. PIP language comes from the supplied footage; coverage is shown as subject to eligibility. The consultation is free; exams and treatment may incur charges.

The video says “Tap below” and refers to a short form and appointment time. Run it with a Meta destination that actually offers that flow, such as your booking landing page. A suggested CTA button is **Book Now**.

Suggested primary ad text:

Care after a car accident starts with a conversation. Meet Dr. Andrew at Kinetic Chiropractic in Pleasant Grove to discuss what happened, your care options and whether Utah PIP benefits may apply. Request a free consultation today.

Suggested headline: **Request a Free Consultation**

Booking link from the clinic website: https://kineticchiropracticutah.janeapp.com/
